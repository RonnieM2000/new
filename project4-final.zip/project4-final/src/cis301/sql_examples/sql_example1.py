import sqlite3

def connect():
    conn = sqlite3.connect('test1.db')
    if conn:
        print("created test1.db")
        return conn

    else:
        print("could not create db")
        return None

def  create_phonebooktbl():

    print("creating a phonebook table")
    conn = connect()

    if conn == None:
        return

    conn.execute('''
    CREATE TABLE PHONEBOOK
    (ID INT PRIMARY  KEY NOT NULL,
    NAME           TEXT NIT NULL,
    PHONE          TEXT NOT NULL,
    EMAIL          TEXT NOT NULL);
    ''')

    conn.close()
    print("DONE!")


def insertContact():
    conn = connect()
    if conn == None:
        return

    conn.execute("INSERT INTO PHONEBOOK(NAME, PHONE, EMAIL) values('dorien','734-646-5555','wheeler@cau.edu')")
    conn.commit()
    conn.close()

def select_contact():
    conn = connect()
    cur = conn.execute("SELECT ID, NAME, PHONE, EMAIL from PHONEBOOK")

    if cur == None:
        return

    for row in cur:
        print (f'ID:{row[0]},\t Email:{row[3]}')

    conn.close()


if __name__ == '__main__':
    # connect()
    #create_phonebooktbl()
    insertContact()
    select_contact()