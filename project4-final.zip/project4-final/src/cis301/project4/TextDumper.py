from cis301.phonebill.phonebill_dumper import PhoneBillDumper


class TextDumper(PhoneBillDumper):
    pass